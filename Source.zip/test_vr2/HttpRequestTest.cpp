// Fill out your copyright notice in the Description page of Project Settings.

#include "test_vr2.h"
#include "HttpRequestTest.h"


FString responseResult, updatePlayerPositionCallBackResponse, seatNumberBeforeParse;
FString makeNewPublicRoomResponse[1], makeNewPrivateRoomResponse[1], getRoomListResponse[1], inRoomUserListResponse[1];
int wantGoInToTargetPublicRoomResponse = -2;
int sampleCalculateProcessResponse[1];
FVector allPlayerPosition[1], allPlayerDirection[1], allPlayerMotion[1];
UHttpRequestTest::FVectorLinkedListMaster *allPlayersPosition = nullptr, *allPlayersDirection = nullptr, *allPlayersMotion = nullptr;
UHttpRequestTest::NetworkTrafficControlMaster *networkTrafficControlMaster = nullptr;
FString amILoggedIn = "none";
bool waitForResponse;

UHttpRequestTest::UHttpRequestTest(const class FObjectInitializer &objInit)
	: Super(objInit)
{
	httpTestModule = &FHttpModule::Get();
}

void UHttpRequestTest::DataBufferLinkedListInit()
{
	allPlayersPosition = new UHttpRequestTest::FVectorLinkedListMaster;
	allPlayersPosition->front = nullptr;
	allPlayersPosition->rear = nullptr;

	networkTrafficControlMaster = new UHttpRequestTest::NetworkTrafficControlMaster;
	networkTrafficControlMaster->front = nullptr;
	networkTrafficControlMaster->rear = nullptr;

	waitForResponse = false;
}

void UHttpRequestTest::NetworkTrafficUpdate()
{
	UHttpRequestTest::NetworkTrafficControlNode *searchNode = networkTrafficControlMaster->front;
	if (searchNode)
	{
		if (!waitForResponse)
		{
			waitForResponse = true;
			TSharedRef<IHttpRequest> httpRequest = FHttpModule::Get().CreateRequest();//httpTestModule->CreateRequest();
			httpRequest->OnProcessRequestComplete().BindStatic(searchNode->CallBackFunc); //CreateStatic(&UHttpRequestTest::ReceiveHttpResult);//
			FlushTargetHttp(httpRequest, searchNode->targetUrl);
		}
		if (searchNode->isExecuted && waitForResponse)
		{
			waitForResponse = false;
			DelNetworkNode(networkTrafficControlMaster);
		}
	}
}

FString UHttpRequestTest::DebugUserSeatNumber()
{
	return seatNumberBeforeParse;
}

FVector UHttpRequestTest::GetSpecialPlayerPosition(int characterNumber)
{
	if (IsFVectorNodeAvailable(allPlayersPosition))
	{
		UHttpRequestTest::FVectorLinkedListNode node = SearchFVectorNode(allPlayersPosition, characterNumber);
		if (node.vectorData != (FVector)NULL)
			return node.vectorData;
	}
	return FVector();
}

FVector UHttpRequestTest::GetSpecialPlayerDirection(int characterNumber)
{
	return FVector();
}

FVector UHttpRequestTest::GetSpecialPlayerMotion(int characterNumber)
{
	return FVector();
}

void UHttpRequestTest::TestServerConnection()
{
	/*TSharedRef<IHttpRequest> httpRequest = FHttpModule::Get().CreateRequest();//httpTestModule->CreateRequest();
	httpRequest->OnProcessRequestComplete().BindStatic(UHttpRequestTest::TestServerConnectionCallBack); //CreateStatic(&UHttpRequestTest::ReceiveHttpResult);//
	FlushTargetHttp(httpRequest, "http://stories2.iptime.org:8078/Smoothie/1/BackEndMessagingTest/SendMessage/0");*/
	AddNetworkNode(networkTrafficControlMaster, &UHttpRequestTest::TestServerConnectionCallBack, "http://stories2.iptime.org:8078/Smoothie/1/BackEndMessagingTest/SendMessage/0");
}

void UHttpRequestTest::SampleCalculateProcess(int targetA, int targetB)
{
	FString targetAInt, targetBInt;
	targetAInt = FString::FromInt(targetA);
	targetBInt = FString::FromInt(targetB);

	/*TSharedRef<IHttpRequest> httpRequest = FHttpModule::Get().CreateRequest();//httpTestModule->CreateRequest();
	httpRequest->OnProcessRequestComplete().BindStatic(UHttpRequestTest::SampleCalculateProcessCallBack); //CreateStatic(&UHttpRequestTest::ReceiveHttpResult);//
	FlushTargetHttp(httpRequest, "http://stories2.iptime.org:8078/Smoothie/1/CharacterInfo/SampleCalculateProcess/2/" + targetAInt + "/" + targetBInt);*/
	AddNetworkNode(networkTrafficControlMaster, &UHttpRequestTest::SampleCalculateProcessCallBack, "http://stories2.iptime.org:8078/Smoothie/1/CharacterInfo/SampleCalculateProcess/2/" + targetAInt + "/" + targetBInt);
}

void UHttpRequestTest::AddFVectorNode(UHttpRequestTest::FVectorLinkedListMaster * targetDataMaster, FVector vectorData)
{
	UHttpRequestTest::FVectorLinkedListNode *node = new UHttpRequestTest::FVectorLinkedListNode;
	if (node != nullptr)
	{
		node->vectorData = vectorData;
		node->nextLink = nullptr;
		/*node->isExecuted = false;
		node->httpRequestWithNoneParameter = nullptr;
		node->httpRequestWithOneFStringOneIntOneFVectorParameter = nullptr;
		node->httpRequestWithOneFStringParameter = nullptr;
		node->httpRequestWithThreeFStringParameter = nullptr;
		node->httpRequestWithTwoFStringOneIntParameter = nullptr;
		node->httpRequestWithTwoFStringParameter = nullptr;
		node->httpRequestWithTwoIntParameter = nullptr;*/
		if (IsFVectorNodeAvailable(targetDataMaster))
		{
			targetDataMaster->rear->nextLink = node;
		}
		else
		{
			targetDataMaster->front = node;
		}
		targetDataMaster->rear = node;
	}
}

void UHttpRequestTest::AddFStringNode(UHttpRequestTest::FStringLinkedListMaster * targetDataMaster, FString stringData)
{
	UHttpRequestTest::FStringLinkedListNode *node = new UHttpRequestTest::FStringLinkedListNode;
	if (node != nullptr)
	{
		node->stringData = stringData;
		node->nextLink = nullptr;
		if (IsFStringNodeAvailable(targetDataMaster))
		{
			targetDataMaster->rear->nextLink = node;
		}
		else
		{
			targetDataMaster->front = node;
		}
		targetDataMaster->rear = node;
	}
}

bool UHttpRequestTest::IsFVectorNodeAvailable(UHttpRequestTest::FVectorLinkedListMaster * targetDataMaster)
{
	return targetDataMaster->front != nullptr;
}

bool UHttpRequestTest::IsFStringNodeAvailable(UHttpRequestTest::FStringLinkedListMaster * targetDataMaster)
{
	return targetDataMaster->front != nullptr;
}

FVector UHttpRequestTest::DelFVectorNode(UHttpRequestTest::FVectorLinkedListMaster * targetDataMaster)
{
	if (!IsFVectorNodeAvailable(targetDataMaster))
		return FVector();
	FVector savedData;
	UHttpRequestTest::FVectorLinkedListNode *node = targetDataMaster->front;
	savedData = node->vectorData;
	targetDataMaster->front = targetDataMaster->front->nextLink;
	delete(node);
	return savedData;
}

FString UHttpRequestTest::DelFStringNode(UHttpRequestTest::FStringLinkedListMaster * targetDataMaster)
{
	if (!IsFStringNodeAvailable(targetDataMaster))
		return FString();
	FString savedData;
	UHttpRequestTest::FStringLinkedListNode *node = targetDataMaster->front;
	savedData = node->stringData;
	targetDataMaster->front = targetDataMaster->front->nextLink;
	delete(node);
	return savedData;
}

UHttpRequestTest::FVectorLinkedListNode UHttpRequestTest::SearchFVectorNode(UHttpRequestTest::FVectorLinkedListMaster * targetDataMaster, int searchNumber)
{
	UHttpRequestTest::FVectorLinkedListNode *searchNode = nullptr;
	if (!IsFVectorNodeAvailable(targetDataMaster))
		return *searchNode;
	searchNode = targetDataMaster->front;
	int cnt = 0;
	while (searchNode != nullptr)
	{
		if (cnt == searchNumber)
			break;
		searchNode = searchNode->nextLink;
		cnt += 1;
	}
	return *searchNode;
}

UHttpRequestTest::FStringLinkedListNode UHttpRequestTest::SearchFStringNode(UHttpRequestTest::FStringLinkedListMaster * targetDataMaster, int searchNumber)
{
	UHttpRequestTest::FStringLinkedListNode *searchNode = nullptr;
	if (!IsFStringNodeAvailable(targetDataMaster))
		return *searchNode;
	searchNode = targetDataMaster->front;
	int cnt = 0;
	while (searchNode != nullptr)
	{
		if (cnt == searchNumber)
			break;
		searchNode = searchNode->nextLink;
		cnt += 1;
	}
	return *searchNode;
}

void UHttpRequestTest::DelAllFVectorNode(UHttpRequestTest::FVectorLinkedListMaster * targetDataMaster)
{
	if (IsFVectorNodeAvailable(targetDataMaster))
	{
		while (targetDataMaster->front != nullptr)
		{
			UHttpRequestTest::FVectorLinkedListNode *node = targetDataMaster->front;
			targetDataMaster->front = targetDataMaster->front->nextLink;
			delete(node);
		}
	}
}

void UHttpRequestTest::DelAllFStringNode(UHttpRequestTest::FStringLinkedListMaster * targetDataMaster)
{
	if (IsFStringNodeAvailable(targetDataMaster))
	{
		while (targetDataMaster->front != nullptr)
		{
			UHttpRequestTest::FStringLinkedListNode *node = targetDataMaster->front;
			targetDataMaster->front = targetDataMaster->front->nextLink;
			delete(node);
		}
	}
}

void UHttpRequestTest::AddNetworkNode(UHttpRequestTest::NetworkTrafficControlMaster * targetNetworkTrafficControlMaster, void(*CallBackFunc)(FHttpRequestPtr, FHttpResponsePtr, bool), FString url)
{
	//AddNetworkNode(nullptr, &UHttpRequestTest::ReceiveHttpResult, "");
	UHttpRequestTest::NetworkTrafficControlNode *node = new UHttpRequestTest::NetworkTrafficControlNode;
	if (node)
	{
		node->isExecuted = false;
		node->targetUrl = url;
		node->CallBackFunc = CallBackFunc;
		node->nextNode = nullptr;
		if (IsNetworkNodeAvailable(targetNetworkTrafficControlMaster))
		{
			targetNetworkTrafficControlMaster->rear->nextNode = node;
		}
		else
		{
			targetNetworkTrafficControlMaster->front = node;
		}
		targetNetworkTrafficControlMaster->rear = node;
	}
}

bool UHttpRequestTest::IsNetworkNodeAvailable(UHttpRequestTest::NetworkTrafficControlMaster * targetNetworkTrafficControlMaster)
{
	return targetNetworkTrafficControlMaster->front != nullptr;
}

bool UHttpRequestTest::DelNetworkNode(UHttpRequestTest::NetworkTrafficControlMaster * targetNetworkTrafficControlMaster)
{
	if (!IsNetworkNodeAvailable(targetNetworkTrafficControlMaster))
		return false;
	UHttpRequestTest::NetworkTrafficControlNode *node = targetNetworkTrafficControlMaster->front;
	targetNetworkTrafficControlMaster->front = targetNetworkTrafficControlMaster->front->nextNode;
	delete(node);
	return true;
}

void UHttpRequestTest::SampleAddSubtractProcess(int targetA, int targetB)
{
}

void UHttpRequestTest::SampleAddProcess(int targetA, int targetB)
{
}

void UHttpRequestTest::MatchUserIdAndPasswd(FString userId, FString userPw)
{
	AddNetworkNode(networkTrafficControlMaster, &UHttpRequestTest::MatchUserIdAndPasswdCallBack, "http://stories2.iptime.org:8078/Smoothie/1/BackEndMessagingTest/SqlTestMessage/2/" + userId + "/" + userPw);
}

void UHttpRequestTest::GetUserNameFunc(FString userId, FString userPw)
{
}

void UHttpRequestTest::SingUp(FString userId, FString userPw, FString userName, FString userBirthDay)
{
}

void UHttpRequestTest::RequestTargetHttpLink(FString url)
{
	/*TSharedRef<IHttpRequest> httpRequest = FHttpModule::Get().CreateRequest();//httpTestModule->CreateRequest();
	httpRequest->OnProcessRequestComplete().BindStatic(&UHttpRequestTest::ReceiveHttpResult); //CreateStatic(&UHttpRequestTest::ReceiveHttpResult);//
	FlushTargetHttp(httpRequest, url);*/
	AddNetworkNode(networkTrafficControlMaster, &UHttpRequestTest::ReceiveHttpResult, url);
}

void UHttpRequestTest::FlushTargetHttp(TSharedRef<IHttpRequest> httpRequest, FString url)
{
	httpRequest->SetURL(url);
	httpRequest->SetVerb("GET");
	httpRequest->SetHeader(TEXT("User-Agent"), "X-UnrealEngin-Agent");
	httpRequest->SetHeader("Content-Type", TEXT("application/html"));
	httpRequest->ProcessRequest();
}

FString UHttpRequestTest::GetResponseResult()
{
	return responseResult;
}

int & UHttpRequestTest::SampleCalculateProcessResponse()
{
	// TODO: ���⿡ ��ȯ ������ �����մϴ�.
	return *sampleCalculateProcessResponse;
}

int UHttpRequestTest::SampleAddSubtractProcessResponse()
{
	return 0;
}

int UHttpRequestTest::SampleAddProcessResponse()
{
	return 0;
}

FString UHttpRequestTest::MatchUserIdAndPasswdResponse()
{
	return amILoggedIn;
}

FString UHttpRequestTest::GetUserNameFuncResponse()
{
	return FString();
}

FString UHttpRequestTest::SingUpResponse()
{
	return FString();
}

FString& UHttpRequestTest::MakeNewPublicRoomResponse()
{
	return *makeNewPublicRoomResponse;
}

FString& UHttpRequestTest::MakeNewPrivateRoomResponse()
{
	return *makeNewPrivateRoomResponse;
}

int UHttpRequestTest::GetHowManyRoomsResponse()
{
	return 0;
}

FString& UHttpRequestTest::GetRoomListResponse()
{
	return *getRoomListResponse;
}

int UHttpRequestTest::WantGoInToTargetPublicRoomResponse()
{
	return wantGoInToTargetPublicRoomResponse;
}

int UHttpRequestTest::WantGoInToTargetPrivateRoomResponse()
{
	return 0;
}

FString& UHttpRequestTest::InRoomUserListResponse()
{
	return *inRoomUserListResponse;
}

FString UHttpRequestTest::WantGoOutFromTargetPublicRoomResponse()
{
	return FString();
}

FString UHttpRequestTest::UpdatePlayerPositionResponse()
{
	return FString();
}

FString UHttpRequestTest::UpdatePlayerDirectionResponse()
{
	return FString();
}

FString UHttpRequestTest::UpdatePlayerMotionResponse()
{
	return FString();
}

FVector& UHttpRequestTest::GetAllPlayerPositionDataResponse()
{
	return *allPlayerPosition;
}

FVector& UHttpRequestTest::GetAllPlayerDirectionDataResponse()
{
	return *allPlayerDirection;
}

FVector& UHttpRequestTest::GetAllPlayerMotionDataResponse()
{
	return *allPlayerMotion;
}

void UHttpRequestTest::MakeNewPublicRoom(FString userId, FString roomTitle, int roomScale)
{
}

void UHttpRequestTest::MakeNewPrivateRoom(FString userId, FString roomPw, FString roomTitle, int roomScale)
{
}

void UHttpRequestTest::GetHowManyRooms()
{
}

void UHttpRequestTest::GetRoomList(int startSearchPoint, int length)
{
}

void UHttpRequestTest::WantGoInToTargetPublicRoom(FString userId, FString roomId)
{
	/*TSharedRef<IHttpRequest> httpRequest = FHttpModule::Get().CreateRequest();//httpTestModule->CreateRequest();
	httpRequest->OnProcessRequestComplete().BindStatic(UHttpRequestTest::WantGoInToTargetPublicRoomCallBack); //CreateStatic(&UHttpRequestTest::ReceiveHttpResult);//
	FlushTargetHttp(httpRequest, "http://stories2.iptime.org:8078/Smoothie/1/UseRoom/WantGoInToTargetPublicRoom/2/" + userId + "/" + roomId);*/
	AddNetworkNode(networkTrafficControlMaster, &UHttpRequestTest::WantGoInToTargetPublicRoomCallBack, "http://stories2.iptime.org:8078/Smoothie/1/UseRoom/WantGoInToTargetPublicRoom/2/" + userId + "/" + roomId);
}

void UHttpRequestTest::WantGoInToTargetPrivateRoom(FString userId, FString roomId, FString roomPw)
{
}

void UHttpRequestTest::InRoomUserList(FString userId)
{
}

void UHttpRequestTest::WantGoOutFromTargetPublicRoom(FString userId, FString roomId, int userSeatNumber)
{
}

void UHttpRequestTest::UpdatePlayerPosition(FString roomId, int userSeatNumber, FVector playerPosition)
{
	FString playerX, playerY, playerZ, userSeatNum;
	playerX = FString::SanitizeFloat(playerPosition.X);
	playerY = FString::SanitizeFloat(playerPosition.Y);
	playerZ = FString::SanitizeFloat(playerPosition.Z);
	userSeatNum = FString::FromInt(userSeatNumber);

	/*TSharedRef<IHttpRequest> httpRequest = FHttpModule::Get().CreateRequest();//httpTestModule->CreateRequest();
	httpRequest->OnProcessRequestComplete().BindStatic(UHttpRequestTest::UpdatePlayerPositionCallBack); //CreateStatic(&UHttpRequestTest::ReceiveHttpResult);//
	FlushTargetHttp(httpRequest, "http://stories2.iptime.org:8078/Smoothie/1/PlayControl/UpdatePlayerPosition/5/" + roomId + "/" + userSeatNum + "/" + playerX + "/" + playerY + "/" + playerZ);*/
	AddNetworkNode(networkTrafficControlMaster, &UHttpRequestTest::UpdatePlayerPositionCallBack, "http://stories2.iptime.org:8078/Smoothie/1/PlayControl/UpdatePlayerPosition/5/" + roomId + "/" + userSeatNum + "/" + playerX + "/" + playerY + "/" + playerZ);
}

void UHttpRequestTest::UpdatePlayerDirection(FString roomId, int userSeatNumber, FVector playerDirection)
{
}

void UHttpRequestTest::UpdatePlayerMotion(FString roomId, int userSeatNumber, FVector playerMotion)
{
}

void UHttpRequestTest::GetAllPlayerPositionData(FString roomId)
{
	/*if (!waitForResponse)
	{
	waitForResponse = true;
	TSharedRef<IHttpRequest> httpRequest = FHttpModule::Get().CreateRequest();//httpTestModule->CreateRequest();
	httpRequest->OnProcessRequestComplete().BindStatic(UHttpRequestTest::GetAllPlayerPositionDataCallBack); //CreateStatic(&UHttpRequestTest::ReceiveHttpResult);//
	FlushTargetHttp(httpRequest, "http://stories2.iptime.org:8078/Smoothie/1/PlayControl/GetAllPlayerPositionData/1/" + roomId);
	}*/
	AddNetworkNode(networkTrafficControlMaster, &UHttpRequestTest::GetAllPlayerPositionDataCallBack, "http://stories2.iptime.org:8078/Smoothie/1/PlayControl/GetAllPlayerPositionData/1/" + roomId);
}

void UHttpRequestTest::GetAllPlayerDirectionData(FString roomId)
{
}

void UHttpRequestTest::GetAllPlayerMotionData(FString roomId)
{
}

void UHttpRequestTest::ReceiveHttpResult(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful)
{
	responseResult = httpResponse->GetContentAsString();
}

void UHttpRequestTest::TestServerConnectionCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful)
{
	httpResponse->GetContentAsString();
	if (IsNetworkNodeAvailable(networkTrafficControlMaster))
		networkTrafficControlMaster->front->isExecuted = true;
}

void UHttpRequestTest::SampleCalculateProcessCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful)
{
	httpResponse->GetContentAsString();
	if (IsNetworkNodeAvailable(networkTrafficControlMaster))
		networkTrafficControlMaster->front->isExecuted = true;
}

void UHttpRequestTest::SampleAddSubtractProcessCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful)
{
	httpResponse->GetContentAsString();
	if (IsNetworkNodeAvailable(networkTrafficControlMaster))
		networkTrafficControlMaster->front->isExecuted = true;
}

void UHttpRequestTest::SampleAddProcessCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful)
{
	httpResponse->GetContentAsString();
	if (IsNetworkNodeAvailable(networkTrafficControlMaster))
		networkTrafficControlMaster->front->isExecuted = true;
}

void UHttpRequestTest::MatchUserIdAndPasswdCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful)
{
	amILoggedIn = httpResponse->GetContentAsString();
	if (IsNetworkNodeAvailable(networkTrafficControlMaster))
		networkTrafficControlMaster->front->isExecuted = true;
}

void UHttpRequestTest::GetUserNameFuncCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful)
{
	httpResponse->GetContentAsString();
	if (IsNetworkNodeAvailable(networkTrafficControlMaster))
		networkTrafficControlMaster->front->isExecuted = true;
}

void UHttpRequestTest::SingUpCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful)
{
	httpResponse->GetContentAsString();
	if (IsNetworkNodeAvailable(networkTrafficControlMaster))
		networkTrafficControlMaster->front->isExecuted = true;
}

void UHttpRequestTest::MakeNewPublicRoomCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful)
{
	httpResponse->GetContentAsString();
	if (IsNetworkNodeAvailable(networkTrafficControlMaster))
		networkTrafficControlMaster->front->isExecuted = true;
}

void UHttpRequestTest::MakeNewPrivateRoomCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful)
{
	httpResponse->GetContentAsString();
	if (IsNetworkNodeAvailable(networkTrafficControlMaster))
		networkTrafficControlMaster->front->isExecuted = true;
}

void UHttpRequestTest::GetHowManyRoomsCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful)
{
	httpResponse->GetContentAsString();
	if (IsNetworkNodeAvailable(networkTrafficControlMaster))
		networkTrafficControlMaster->front->isExecuted = true;
}

void UHttpRequestTest::GetRoomListCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful)
{
	httpResponse->GetContentAsString();
	if (IsNetworkNodeAvailable(networkTrafficControlMaster))
		networkTrafficControlMaster->front->isExecuted = true;
}

void UHttpRequestTest::WantGoInToTargetPublicRoomCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful)
{
	wantGoInToTargetPublicRoomResponse = -2;
	FString result = httpResponse->GetContentAsString();
	seatNumberBeforeParse = result;
	wantGoInToTargetPublicRoomResponse = FCString::Atoi(*result);
	/*try
	{
	}
	catch ()//(UHttpRequestTest& except)
	{
	wantGoInToTargetPublicRoomResponse = -1;
	}*/
	if (IsNetworkNodeAvailable(networkTrafficControlMaster))
		networkTrafficControlMaster->front->isExecuted = true;
}

void UHttpRequestTest::WantGoInToTargetPrivateRoomCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful)
{
	httpResponse->GetContentAsString();
	if (IsNetworkNodeAvailable(networkTrafficControlMaster))
		networkTrafficControlMaster->front->isExecuted = true;
}

void UHttpRequestTest::InRoomUserListCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful)
{
	httpResponse->GetContentAsString();
	if (IsNetworkNodeAvailable(networkTrafficControlMaster))
		networkTrafficControlMaster->front->isExecuted = true;
}

void UHttpRequestTest::WantGoOutFromTargetPublicRoomCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful)
{
	httpResponse->GetContentAsString();
	if (IsNetworkNodeAvailable(networkTrafficControlMaster))
		networkTrafficControlMaster->front->isExecuted = true;
}

void UHttpRequestTest::UpdatePlayerPositionCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful)
{
	updatePlayerPositionCallBackResponse = httpResponse->GetContentAsString();
	if (IsNetworkNodeAvailable(networkTrafficControlMaster))
		networkTrafficControlMaster->front->isExecuted = true;
}

void UHttpRequestTest::UpdatePlayerDirectionCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful)
{
	httpResponse->GetContentAsString();
	if (IsNetworkNodeAvailable(networkTrafficControlMaster))
		networkTrafficControlMaster->front->isExecuted = true;
}

void UHttpRequestTest::UpdatePlayerMotionCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful)
{
	httpResponse->GetContentAsString();
	if (IsNetworkNodeAvailable(networkTrafficControlMaster))
		networkTrafficControlMaster->front->isExecuted = true;
}

void UHttpRequestTest::GetAllPlayerPositionDataCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful)
{
	DelAllFVectorNode(allPlayersPosition);
	FString returnData = httpResponse->GetContentAsString(), tempString = "";
	int i, cnt = 0;
	bool isNotEmpty = false;
	FVector resultData;
	for (i = 0; i < returnData.Len(); i += 1)
	{
		if (IsNumberCharacter(returnData[i]))
		{
			tempString = tempString + returnData[i];
			isNotEmpty = true;
		}
		else
		{
			if (isNotEmpty)
			{
				isNotEmpty = false;
				if (cnt % 3 == 0)
				{
					resultData = FVector();
					resultData.X = FCString::Atof(*tempString);
				}
				else if (cnt % 3 == 1)
				{
					resultData.Y = FCString::Atof(*tempString);
				}
				else
				{
					resultData.Z = FCString::Atof(*tempString);
					AddFVectorNode(allPlayersPosition, resultData);
				}
				cnt += 1;
				tempString = "";
			}
		}
	}
	if (IsNetworkNodeAvailable(networkTrafficControlMaster))
		networkTrafficControlMaster->front->isExecuted = true;
}

void UHttpRequestTest::GetAllPlayerDirectionDataCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful)
{
	httpResponse->GetContentAsString();
	if (IsNetworkNodeAvailable(networkTrafficControlMaster))
		networkTrafficControlMaster->front->isExecuted = true;
}

void UHttpRequestTest::GetAllPlayerMotionDataCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful)
{
	httpResponse->GetContentAsString();
	if (IsNetworkNodeAvailable(networkTrafficControlMaster))
		networkTrafficControlMaster->front->isExecuted = true;
}
