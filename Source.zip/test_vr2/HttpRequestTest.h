// Fill out your copyright notice in the Description page of Project Settings.

#pragma once
#include "Runtime/Online/HTTP/Public/Http.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "HttpRequestTest.generated.h"

/**
 * 
 */
UCLASS()
class TEST_VR2_API UHttpRequestTest : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

		//������ �����ϴ� API �߿����� ������ ������ �� ����� �׽�Ʈ�ϴ� API�̴�
		static void TestServerConnectionCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful);

	//���� ���� ����
	static void SampleCalculateProcessCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful);

	//�� ����
	static void SampleAddSubtractProcessCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful);

	//�� ����
	static void SampleAddProcessCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful);

	static void MatchUserIdAndPasswdCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful);

	static void GetUserNameFuncCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful);

	static void SingUpCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful);

	static void MakeNewPublicRoomCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful);

	static void MakeNewPrivateRoomCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful);

	static void GetHowManyRoomsCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful);

	static void GetRoomListCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful);

	static void WantGoInToTargetPublicRoomCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful);

	static void WantGoInToTargetPrivateRoomCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful);

	static void InRoomUserListCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful);

	//static void InRoomGameStartCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful);

	//static void InRoomSetReadyCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful);

	static void WantGoOutFromTargetPublicRoomCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful);

	//static void WantGoOutFromTargetPrivateRoomCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful);

	static void UpdatePlayerPositionCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful);

	static void UpdatePlayerDirectionCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful);

	static void UpdatePlayerMotionCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful);

	static void GetAllPlayerPositionDataCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful);

	static void GetAllPlayerDirectionDataCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful);

	static void GetAllPlayerMotionDataCallBack(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful);

	static void ReceiveHttpResult(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful);// FHttpRequestPtr FHttpResponsePtr

public:

	FHttpModule *httpTestModule;

	struct FVectorLinkedListNode
	{
		FVector vectorData;
		/*bool isExecuted;
		void(*httpRequestWithNoneParameter)();
		void(*httpRequestWithOneFStringParameter)(FString);
		void(*httpRequestWithTwoIntParameter)(int, int);
		void(*httpRequestWithTwoFStringParameter)(FString, FString);
		void(*httpRequestWithTwoFStringOneIntParameter)(FString, FString, int);
		void(*httpRequestWithThreeFStringParameter)(FString, FString, FString);
		void(*httpRequestWithOneFStringOneIntOneFVectorParameter)(FString, int, FVector);*/
		FVectorLinkedListNode *nextLink;
	};
	struct FVectorLinkedListMaster
	{
		FVectorLinkedListNode *front, *rear;
	};
	struct FStringLinkedListNode
	{
		FString stringData;
		FStringLinkedListNode *nextLink;
	};
	struct FStringLinkedListMaster
	{
		FStringLinkedListNode *front, *rear;
	};

	//�������� Ŭ���̾�Ʈ�� ������ �����Ͱ� �󸶳� ������ �𸣹Ƿ� ��ũ�� ����Ʈ�� �̿��� ���� ����� ����
	static void AddFVectorNode(UHttpRequestTest::FVectorLinkedListMaster *targetDataMaster, FVector vectorData);
	static void AddFStringNode(UHttpRequestTest::FStringLinkedListMaster *targetDataMaster, FString stringData);
	static bool IsFVectorNodeAvailable(UHttpRequestTest::FVectorLinkedListMaster *targetDataMaster);
	static bool IsFStringNodeAvailable(UHttpRequestTest::FStringLinkedListMaster *targetDataMaster);
	static FVector DelFVectorNode(UHttpRequestTest::FVectorLinkedListMaster *targetDataMaster);
	static FString DelFStringNode(UHttpRequestTest::FStringLinkedListMaster *targetDataMaster);
	static UHttpRequestTest::FVectorLinkedListNode SearchFVectorNode(UHttpRequestTest::FVectorLinkedListMaster *targetDataMaster, int searchNumber);
	static UHttpRequestTest::FStringLinkedListNode SearchFStringNode(UHttpRequestTest::FStringLinkedListMaster *targetDataMaster, int searchNumber);
	static void DelAllFVectorNode(UHttpRequestTest::FVectorLinkedListMaster *targetDataMaster);
	static void DelAllFStringNode(UHttpRequestTest::FStringLinkedListMaster *targetDataMaster);


	struct NetworkTrafficControlNode
	{
		void(*CallBackFunc)(FHttpRequestPtr, FHttpResponsePtr, bool);
		bool isExecuted;
		FString targetUrl;
		NetworkTrafficControlNode *nextNode;
	};

	struct NetworkTrafficControlMaster
	{
		NetworkTrafficControlNode *front, *rear;
	};

	//Ŭ���̾�Ʈ���� ������ ���� �����͸� �ʹ� ������ ������ ������ ������ ���Ƿ� Ʈ���� ����
	static void AddNetworkNode(UHttpRequestTest::NetworkTrafficControlMaster *targetNetworkTrafficControlMaster, void(*CallBackFunc)(FHttpRequestPtr, FHttpResponsePtr, bool), FString url);
	static bool IsNetworkNodeAvailable(UHttpRequestTest::NetworkTrafficControlMaster *targetNetworkTrafficControlMaster);
	static bool DelNetworkNode(UHttpRequestTest::NetworkTrafficControlMaster *targetNetworkTrafficControlMaster);
	//typedef void (UHttpRequestTest::*FuncPtr)(FHttpRequestPtr httpRequest, FHttpResponsePtr httpResponse, bool isSuccessful);

	//�����͸� ���� ������ http ��ũ�� �����Ѵ�
	static void RequestTargetHttpLink(FString url);
	//������ ��ũ�� �䵥�� ���� ������Ʈ�� ������
	static void FlushTargetHttp(TSharedRef<IHttpRequest> httpRequest, FString url);
	//���� �Ǻ�
	static bool IsNumberCharacter(char data)
	{
		return ('0' <= data && data <= '9') || data == '-' || data == '.';
	}
	//c++�� ������
	UHttpRequestTest(const class FObjectInitializer &objInit);

	/*
	http system
	*/

	UFUNCTION(BlueprintCallable, Category = "Http System")
		static void DataBufferLinkedListInit();

	UFUNCTION(BlueprintCallable, Category = "Http System")
		static void NetworkTrafficUpdate();

	//UFUNCTION(BlueprintCallable, Category = "Http System")
	static FString DebugUserSeatNumber();

	/*
	http local
	*/

	UFUNCTION(BlueprintCallable, Category = "Http Local")
		static FVector GetSpecialPlayerPosition(int characterNumber);

	UFUNCTION(BlueprintCallable, Category = "Http Local")
		static FVector GetSpecialPlayerDirection(int characterNumber);

	UFUNCTION(BlueprintCallable, Category = "Http Local")
		static FVector GetSpecialPlayerMotion(int characterNumber);

	/*
	http request
	*/

	//������ �����ϴ� API �߿����� ������ ������ �� ����� �׽�Ʈ�ϴ� API�̴�
	UFUNCTION(BlueprintCallable, Category = "Http Test Request")
		static void TestServerConnection();

	//���� ���� ����
	UFUNCTION(BlueprintCallable, Category = "Http Test Request")
		static void SampleCalculateProcess(int targetA, int targetB);

	//�� ����
	UFUNCTION(BlueprintCallable, Category = "Http Test Request")
		static void SampleAddSubtractProcess(int targetA, int targetB);

	//�� ����
	UFUNCTION(BlueprintCallable, Category = "Http Test Request")
		static void SampleAddProcess(int targetA, int targetB);

	UFUNCTION(BlueprintCallable, Category = "Http Get Request")
		static void MatchUserIdAndPasswd(FString userId, FString userPw);

	UFUNCTION(BlueprintCallable, Category = "Http Get Request")
		static void GetUserNameFunc(FString userId, FString userPw);

	UFUNCTION(BlueprintCallable, Category = "Http Get Request")
		static void SingUp(FString userId, FString userPw, FString userName, FString userBirthDay);

	UFUNCTION(BlueprintCallable, Category = "Http Get Request")
		static void MakeNewPublicRoom(FString userId, FString roomTitle, int roomScale);

	UFUNCTION(BlueprintCallable, Category = "Http Get Request")
		static void MakeNewPrivateRoom(FString userId, FString roomPw, FString roomTitle, int roomScale);

	UFUNCTION(BlueprintCallable, Category = "Http Get Request")
		static void GetHowManyRooms();

	UFUNCTION(BlueprintCallable, Category = "Http Get Request")
		static void GetRoomList(int startSearchPoint, int length);

	UFUNCTION(BlueprintCallable, Category = "Http Get Request")
		static void WantGoInToTargetPublicRoom(FString userId, FString roomId);

	UFUNCTION(BlueprintCallable, Category = "Http Get Request")
		static void WantGoInToTargetPrivateRoom(FString userId, FString roomId, FString roomPw);

	UFUNCTION(BlueprintCallable, Category = "Http Get Request")
		static void InRoomUserList(FString userId);

	//UFUNCTION(BlueprintCallable, Category = "Http Get Request")
	//static void InRoomGameStart();

	//UFUNCTION(BlueprintCallable, Category = "Http Get" Request)
	//static void InRoomSetReady();

	UFUNCTION(BlueprintCallable, Category = "Http Get Request")
		static void WantGoOutFromTargetPublicRoom(FString userId, FString roomId, int userSeatNumber);

	//UFUNCTION(BlueprintCallable, Category = "Http Get Request")
	//static void WantGoOutFromTargetPrivateRoom();

	UFUNCTION(BlueprintCallable, Category = "Http Get Request")
		static void UpdatePlayerPosition(FString roomId, int userSeatNumber, FVector playerPosition);

	UFUNCTION(BlueprintCallable, Category = "Http Get Request")
		static void UpdatePlayerDirection(FString roomId, int userSeatNumber, FVector playerDirection);

	UFUNCTION(BlueprintCallable, Category = "Http Get Request")
		static void UpdatePlayerMotion(FString roomId, int userSeatNumber, FVector playerMotion);

	UFUNCTION(BlueprintCallable, Category = "Http Get Request")
		static void GetAllPlayerPositionData(FString roomId);

	UFUNCTION(BlueprintCallable, Category = "Http Get Request")
		static void GetAllPlayerDirectionData(FString roomId);

	UFUNCTION(BlueprintCallable, Category = "Http Get Request")
		static void GetAllPlayerMotionData(FString roomId);

	/*
	Get Response Result
	*/

	UFUNCTION(BlueprintCallable, Category = "Http Test Response")
		static FString GetResponseResult();

	//���� ���� ����
	UFUNCTION(BlueprintCallable, Category = "Http Test Response")
		static int& SampleCalculateProcessResponse();

	//�� ����
	UFUNCTION(BlueprintCallable, Category = "Http Test Response")
		static int SampleAddSubtractProcessResponse();

	//�� ����
	UFUNCTION(BlueprintCallable, Category = "Http Test Response")
		static int SampleAddProcessResponse();

	UFUNCTION(BlueprintCallable, Category = "Http Get Response")
		static FString MatchUserIdAndPasswdResponse();

	UFUNCTION(BlueprintCallable, Category = "Http Get Response")
		static FString GetUserNameFuncResponse();

	UFUNCTION(BlueprintCallable, Category = "Http Get Response")
		static FString SingUpResponse();

	UFUNCTION(BlueprintCallable, Category = "Http Get Response")
		static FString& MakeNewPublicRoomResponse();

	UFUNCTION(BlueprintCallable, Category = "Http Get Response")
		static FString& MakeNewPrivateRoomResponse();

	UFUNCTION(BlueprintCallable, Category = "Http Get Response")
		static int GetHowManyRoomsResponse();

	UFUNCTION(BlueprintCallable, Category = "Http Get Response")
		static FString& GetRoomListResponse();

	UFUNCTION(BlueprintCallable, Category = "Http Get Response")
		static int WantGoInToTargetPublicRoomResponse();

	UFUNCTION(BlueprintCallable, Category = "Http Get Response")
		static int WantGoInToTargetPrivateRoomResponse();

	UFUNCTION(BlueprintCallable, Category = "Http Get Response")
		static FString& InRoomUserListResponse();

	//UFUNCTION(BlueprintCallable, Category = "Http Get Response")
	//static void InRoomGameStartResponse();

	//UFUNCTION(BlueprintCallable, Category = "Http Get" Response)
	//static void InRoomSetReadyResponse();

	UFUNCTION(BlueprintCallable, Category = "Http Get Response")
		static FString WantGoOutFromTargetPublicRoomResponse();

	//UFUNCTION(BlueprintCallable, Category = "Http Get Response")
	//static void WantGoOutFromTargetPrivateRoomResponse();

	UFUNCTION(BlueprintCallable, Category = "Http Get Response")
		static FString UpdatePlayerPositionResponse();

	UFUNCTION(BlueprintCallable, Category = "Http Get Response")
		static FString UpdatePlayerDirectionResponse();

	UFUNCTION(BlueprintCallable, Category = "Http Get Response")
		static FString UpdatePlayerMotionResponse();

	//UFUNCTION(BlueprintCallable, Category = "Http Get Response")
	static FVector& GetAllPlayerPositionDataResponse();

	//UFUNCTION(BlueprintCallable, Category = "Http Get Response")
	static FVector& GetAllPlayerDirectionDataResponse();

	//UFUNCTION(BlueprintCallable, Category = "Http Get Response")
	static FVector& GetAllPlayerMotionDataResponse();

};
