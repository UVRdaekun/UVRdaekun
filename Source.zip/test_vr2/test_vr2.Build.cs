// Copyright 1998-2016 Epic Games, Inc. All Rights Reserved.

using UnrealBuildTool;

public class test_vr2 : ModuleRules
{
	public test_vr2(TargetInfo Target)
	{
        UEBuildConfiguration.bForceEnableExceptions = true;
        //PublicDependencyModuleNames.AddRange(new string[] { "Core", "CoreUObject", "Engine", "InputCore", "Http", "Json", "JsonUtilities", "HTTP" });
        PublicDependencyModuleNames.AddRange(new string[] {
     "Core", "CoreUObject", "Engine", "InputCore",

         "HTTP"   //<~~~~~~~
 });
        PrivateDependencyModuleNames.AddRange(new string[] { "HTTP" });
        PrivateIncludePathModuleNames.AddRange(new string[] { "HTTP" });
    }
}
